'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'jedi-order';
var width = 448;
var height = 512;
var ligatures = [];
var unicode = 'f50e';
var svgPathData = 'M231.89 335.72l31.44-45.89-20.18 55.5 62.56 9.09-62.56 9.08 24.22 47.43s-30.22-31.77-34.49-36.25c1.76 68.78 2.19 85.7 2.19 85.7s154.4-71.65 68.62-230.09c0 0 106.97-118.07 10.09-190.73 0 0 165.5 99.91 60.55 271.46 0 0 86.78-84.77 41.37-170.54 0 0 78.71 111.01-17.16 233.11 0 0 26.24-16.15 49.45-77.71 0 0-16.93 183.26-221.96 185.66v.02h-4.08v-.02C16.93 479.14 0 295.88 0 295.88c23.21 61.56 49.44 77.71 49.44 77.71-95.87-122.11-17.15-233.11-17.15-233.11-45.41 85.78 41.38 170.54 41.38 170.54-104.95-171.56 60.54-271.46 60.54-271.46-96.88 72.66 10.09 190.73 10.09 190.73-85.78 158.44 68.62 230.09 68.62 230.09s.43-16.93 2.19-85.7l-34.48 36.25 24.22-47.43-62.56-9.08 62.56-9.09-20.18-55.5 31.44 45.89c2.25-87.85 7.82-305.82 7.85-306.85l.01-2.43.02 1 .03-1 .01 2.43c.05 1.72 5.61 219.2 7.86 306.85z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    ligatures,
    unicode,
    svgPathData
  ]};

exports.faJediOrder = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = ligatures;
exports.unicode = unicode;
exports.svgPathData = svgPathData;