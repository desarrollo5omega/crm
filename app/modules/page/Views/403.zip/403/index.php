<h1 class="titulo-principal py-2"><i class="fas fa-ban"></i> <?php echo $this->titlesection; ?></h1>

<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="card mt-5">
                <div class="card-body">
                    <div class="alert alert-danger d-flex justify-content-center align-items-center" role="alert">
                        <h2><i class="fas fa-exclamation-triangle"></i> PAGINA RESTRINGIDA</h2>
                    </div>
                </div>            
            </div>
        </div>
    </div>
</div>
